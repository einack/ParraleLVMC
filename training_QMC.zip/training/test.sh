#! /bin/bash
#./a_mpi.out

mpirun -np 2 a_mpi.out 
